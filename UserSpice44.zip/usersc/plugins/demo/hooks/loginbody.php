You can include a link or logo or whatever you want here. This is loginbody.php
