<!-- Make your own menu on the side of the dashboard. Example below. -->
<!-- <li class="menu-item-has-children dropdown ">

           <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-wrench"></i>Custom</a>

           <ul class="sub-menu children dropdown-menu ">

             <li ><i class="menu-icon fa fa-floppy-o"></i><a href="admin.php?view=backup">Link1</a></li>

             <li ><i class="menu-icon fa fa-arrow-circle-o-up"></i><a href="admin.php?view=updates">Link2</a></li>

             <li ><i class="menu-icon fa fa-terminal"></i><a href="admin.php?view=cron">Link3</a></li>

           </ul>

         </li>

<li class="menu-item"> -->
