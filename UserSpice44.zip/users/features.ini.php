;<?php
;die();
dbmenu = 1
forms_legacy = 1
reauth = 1
notifications = 1
fingerprinting = 1
sessions = 1
messaging = 0
saas = 1